# Task 3
# Using inspiration from code in task1.py and simulator.py write the appropriate functions to create the plot required.

import numpy as np
import matplotlib.pyplot as plt
from bernoulli_bandit import *
from task1 import Algorithm
from multiprocessing import Pool

# DEFINE your algorithm class here

# DEFINE single_sim_task3() HERE

# DEFINE simulate_task3() HERE

# DEFINE task3() HERE

# Call task3() to generate the plots